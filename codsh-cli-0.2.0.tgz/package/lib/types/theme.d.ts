/**
 * Terminal styling and display metrics: SGR sequences that degrade to plain
 * text off a TTY, and the display-column width a rendered string occupies.
 * @module codsh-cli/src/theme
 */
/** Style roles the renderer asks for, resolved to SGR codes by {@link createTheme}. */
export interface Theme {
    /** Whether this theme emits SGR sequences at all. */
    readonly colored: boolean;
    dim(text: string): string;
    bold(text: string): string;
    /** Failures, denied approvals, and removed diff lines. */
    error(text: string): string;
    /** Completed work and added diff lines. */
    success(text: string): string;
    /** Pending state and approval prompts. */
    pending(text: string): string;
    /** Tool names and card titles. */
    tool(text: string): string;
    /** File paths and locations. */
    path(text: string): string;
    /** The user's own echoed input. */
    user(text: string): string;
    /** Roles used inside a fenced code block. */
    readonly syntax: SyntaxTheme;
}
/** Styling for the token classes a code block is coloured by. */
export interface SyntaxTheme {
    keyword(text: string): string;
    string(text: string): string;
    number(text: string): string;
    comment(text: string): string;
}
/**
 * Build the theme for one surface.
 *
 * Color is suppressed off a TTY and whenever `NO_COLOR` is set to any value,
 * following the `no-color.org` convention: a redirected transcript stays
 * greppable, and a pipe never receives sequences a reader would have to strip.
 *
 * Secondary text uses a palette gray on a 256-color terminal rather than the
 * `dim` attribute: several terminals render `dim` at full brightness, and a
 * hierarchy nobody can see is no hierarchy — the placeholder, the menu details,
 * and the status row must sit visibly behind what the person typed.
 * @param isTty - whether the output stream is a terminal.
 * @param env - the environment to read `NO_COLOR` and the color depth from.
 * @returns the styling functions for this surface.
 */
export declare function createTheme(isTty: boolean, env: Record<string, string | undefined>): Theme;
/**
 * Display columns a string occupies once printed, ignoring styling sequences.
 *
 * Measured by `string-width` — the width authority cli-table3, ink, and every
 * maintained terminal renderer sit on — so East Asian Wide, emoji presentation
 * (`⚡` included), combining marks, and ZWJ sequences all match what a
 * terminal's cursor actually does. A hand-kept range table here mis-sized `⚡`
 * and sheared a real table's columns; widths are exactly the kind of data
 * nobody should maintain by hand.
 * @param text - the string to measure, possibly carrying SGR sequences.
 * @returns the number of display columns.
 */
export declare function displayWidth(text: string): number;
/**
 * Shorten a string to at most `columns` display columns, marking the cut with
 * an ellipsis when anything was dropped.
 *
 * Styling survives: sequences cost no columns and travel with the text they
 * style, and a cut that kept any styling closes it with a reset before the
 * ellipsis so nothing leaks onto the next row. A string that already fits is
 * returned exactly as it came — a fit is not a licence to restyle it.
 * @param text - the string to shorten, possibly carrying SGR sequences.
 * @param columns - the display-column budget; a budget under 2 yields the empty string.
 * @returns the string, unchanged when it already fits.
 */
export declare function truncate(text: string, columns: number): string;

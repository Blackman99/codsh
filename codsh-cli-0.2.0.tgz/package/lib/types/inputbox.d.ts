/**
 * The input box: a framed, multi-line prompt that wraps long lines, grows with
 * its content, and windows when it grows past its budget — with the completion
 * menu under it.
 *
 * Pure layout. It turns an {@link EditorView} into the rows of the bottom region
 * and says where the terminal cursor belongs, so the drawing code has no opinion
 * about editing and this file has none about terminals.
 *
 * Wrapping is by display width, hard at the boundary: a wrap that respected word
 * breaks would need the same word knowledge in the cursor mapping, and a cursor
 * that disagrees with the wrap by one cell is worse than a word split across
 * rows. Text is never truncated here — hiding typed text is how an input box
 * loses a person's work.
 * @module codsh-cli/src/inputbox
 */
import type { EditorView } from './editor.ts';
import type { Theme } from './theme.ts';
/** What the box is asked to show besides the buffer. */
export interface BoxOptions {
    /** Dim text shown inside an empty box, e.g. what `/` and `@` do. */
    placeholder?: string | undefined;
    /** Dim text shown under the box when the menu is closed. */
    hint?: string | undefined;
    /** Styles the frame; absent frames dim. A mode announces itself here. */
    accent?: ((text: string) => string) | undefined;
}
/** The rows to draw and where the cursor goes among them. */
export interface BoxLayout {
    /** Rows, top to bottom, each already fitted to the terminal. */
    rows: string[];
    /** Index into {@link rows} where the cursor belongs. */
    cursorRow: number;
    /** Display column of the cursor on that row, from zero. */
    cursorColumn: number;
}
/**
 * Lay out the input box.
 * @param view - what the editor is showing.
 * @param theme - styling for the frame, the marker, and the menu.
 * @param columns - display columns available.
 * @param options - placeholder, hint, and frame accent.
 * @returns the rows and cursor position.
 */
export declare function inputBox(view: EditorView, theme: Theme, columns: number, options?: BoxOptions): BoxLayout;

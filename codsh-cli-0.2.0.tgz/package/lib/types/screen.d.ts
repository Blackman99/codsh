/**
 * The session's own screen: an alternate-screen viewport with its own scrollback.
 *
 * This is what makes a session feel like a place rather than a run of output.
 * The terminal's buffer is left exactly as the person had it — their shell
 * history is neither scrolled away nor interleaved — and everything this
 * surface shows lives in a buffer it owns: the transcript scrolls inside the
 * viewport while the input box stays where it is, at the bottom.
 *
 * Owning the viewport means doing three jobs the terminal used to do. Lines are
 * wrapped here ({@link wrapAll}), because a line that overflows would otherwise
 * overwrite the row below. Scrolling is ours, because the terminal's scrollback
 * does not exist on the alternate screen. And every frame is painted as a
 * whole, diffed against the last one — which is what removes the class of bug
 * that relative erase arithmetic keeps producing.
 * @module codsh/src/screen
 */
/** Where the cursor belongs within the chrome rows. */
export interface ChromeCursor {
    row: number;
    column: number;
}
/** What the screen writes to and measures itself against. */
export interface ScreenHost {
    /** Emit raw bytes to the terminal. */
    write(data: string): void;
    /** Display columns currently available. */
    columns(): number;
    /** Screen rows currently available. */
    rows(): number;
}
/** An alternate-screen viewport over a scrollback buffer this surface owns. */
export declare class Screen {
    private readonly host;
    /** Logical transcript lines, unwrapped, oldest first. */
    private logical;
    /** The same lines wrapped to the current width — what the viewport slices. */
    private physical;
    /** The bottom rows: input box, menu, indicator, status. */
    private chrome;
    private chromeCursor;
    /** Whether the chrome holds input focus, which is when the cursor shows. */
    private chromeFocus;
    /** Physical rows hidden below the viewport; zero means following the tail. */
    private offset;
    /** What to show while scrolled back, drawn over the viewport's top row. */
    private notice;
    /** A mouse selection over the transcript, in physical-row coordinates. */
    private selection;
    /** Collapsed blocks in the transcript, in order, with both of their forms. */
    private folds;
    /** Whether the folds currently show their full form. */
    private expanded;
    /** The last painted frame, so a repaint only touches rows that changed. */
    private painted;
    /** Width the current frame was painted at, to detect a resize. */
    private paintedColumns;
    private active;
    constructor(host: ScreenHost);
    /** Whether the alternate screen is currently held. */
    get entered(): boolean;
    /** Physical rows scrolled up out of view; zero means the tail is showing. */
    get scrolledBy(): number;
    /** Take the alternate screen and start reporting the mouse. */
    enter(): void;
    /**
     * Give the terminal back exactly as it was.
     *
     * Idempotent, because every exit path calls it — a normal quit, an
     * interrupt, and a crash handler all have to leave the terminal usable.
     */
    leave(): void;
    /**
     * Append finished transcript lines.
     *
     * Following the tail is the default; a person who has scrolled up stays
     * where they are, and the new rows accumulate below them.
     * @param lines - the lines to keep, already styled.
     */
    append(lines: readonly string[]): void;
    /**
     * Append one collapsible block: its summary now, its full form on demand.
     *
     * This is what makes every long block — not merely the latest — expandable:
     * the buffer keeps both forms, and toggling rebuilds the transcript in
     * place, exactly like a details/summary element.
     * @param summary - the collapsed lines, already styled.
     * @param full - the expanded lines, already styled.
     */
    appendFold(summary: readonly string[], full: readonly string[]): void;
    /**
     * Turn the last `count` appended lines into a collapsible block after the
     * fact.
     *
     * This is how a finished answer becomes foldable without ever having been
     * withheld: it streamed in the open, and only once complete does it grow a
     * summary form. The block starts expanded — the person is reading it — and
     * collapses with the rest when the conversation moves on.
     * @param count - how many trailing lines the block owns.
     * @param summary - the collapsed lines, already styled.
     */
    foldBack(count: number, summary: readonly string[]): void;
    /** Whether any collapsible block exists. */
    get hasFolds(): boolean;
    /** Whether the folds currently show their full form. */
    get foldsExpanded(): boolean;
    /**
     * Swap every fold between its summary and its full form.
     * @returns false when there is nothing to toggle.
     */
    toggleFolds(): boolean;
    /** Return every fold to its summary, the way moving on reads as dismissal. */
    collapseFolds(): void;
    /** Put every fold into one form, whatever mix of states they are in now. */
    private setFolds;
    /**
     * Replace the bottom rows.
     * @param rows - the chrome, top to bottom.
     * @param cursor - where the cursor belongs among them.
     * @param focus - whether to show the cursor there.
     */
    setChrome(rows: readonly string[], cursor: ChromeCursor, focus: boolean): void;
    /**
     * Set the line shown while the reader is away from the tail.
     *
     * Drawn OVER the viewport's top row rather than added to the chrome: a notice
     * that changed the chrome's height would move the input box as a side effect
     * of scrolling, and would make a page up and a page down different sizes.
     * @param text - the styled notice, already fitted.
     */
    setScrollNotice(text: string): void;
    /**
     * Scroll the transcript.
     * @param delta - rows to move; negative scrolls back into history.
     */
    scrollBy(delta: number): void;
    /**
     * Scroll by a whole viewport, which is what the page keys mean.
     * @param direction - -1 for back into history, 1 towards the tail.
     */
    scrollPage(direction: -1 | 1): void;
    /** Jump back to the tail, which is also what a new submission does. */
    scrollToBottom(): void;
    /**
     * Drop the transcript, keeping the chrome.
     *
     * Ctrl-L on a shared terminal clears a viewport the person may want back; on
     * our own screen the buffer IS the session's history, so this empties it.
     */
    clearTranscript(): void;
    /** Re-wrap and repaint after the terminal changed size. */
    resize(): void;
    /**
     * Anchor a selection where the left button went down.
     *
     * The terminal cannot select for us while mouse reporting is on, so the
     * viewport does it: press anchors, motion extends, release copies — the
     * shape opencode and Claude give the same gesture.
     * @param row - terminal row, 1-based.
     * @param column - terminal column, 1-based.
     */
    mouseDown(row: number, column: number): void;
    /**
     * Extend the selection to where the pointer moved.
     * @param row - terminal row, 1-based.
     * @param column - terminal column, 1-based.
     */
    mouseDrag(row: number, column: number): void;
    /**
     * Finish the gesture.
     *
     * The highlight stays up — the copy already happened, and the marks show
     * what it took — until the next click or reflow dismisses it.
     * @returns the selected text, or undefined for a bare click.
     */
    mouseUp(): string | undefined;
    /** The selection's bounds in order, top-left first. */
    private orderedSelection;
    /** The plain text under the selection, visual rows joined by newlines. */
    private selectedText;
    /**
     * Map a terminal position to a physical buffer position.
     * @param row - terminal row, 1-based.
     * @param column - terminal column, 1-based.
     * @param clamp - pull an outside position to the nearest content row, the
     * way dragging past an edge keeps selecting, instead of refusing it.
     * @returns the position, or undefined when it misses the content.
     */
    private locate;
    /** Rows the transcript viewport occupies. */
    private viewportHeight;
    /** Columns content is laid out for, one short of the width so no row wraps. */
    private contentColumns;
    /** Re-wrap every kept line at the current width. */
    private rewrap;
    /**
     * Compose and paint the frame.
     *
     * The viewport is padded at the top when the transcript is shorter than the
     * screen, which is what puts the chrome at the bottom from the first frame
     * rather than wherever output happened to reach.
     */
    private render;
}

/**
 * The prompt's editing model: a multi-line buffer, a cursor, history, and the
 * completion menu.
 *
 * Pure state. It takes keys and answers with what changed, so every behaviour
 * here is testable without a terminal — the rendering and the raw-mode plumbing
 * are somebody else's job.
 * @module codsh-cli/src/editor
 */
import type { CompletableCommand, CompletionResult } from './completion.ts';
import type { Key } from './keys.ts';
/** One entry offered in the completion menu. */
export interface Candidate {
    /** The text that replaces the token when accepted. */
    value: string;
    /** What it does, shown beside it. Empty for a path, which explains itself. */
    detail: string;
}
/** What the editor is showing right now. */
export interface EditorView {
    /** Buffer lines; always at least one, possibly empty. */
    lines: readonly string[];
    /** Cursor line index. */
    row: number;
    /** Cursor column within that line, in code points. */
    column: number;
    /** Candidates to offer, empty when the menu is closed. */
    candidates: readonly Candidate[];
    /** Which candidate is selected, meaningless when there are none. */
    selected: number;
    /** The token under the cursor, which is what the candidates matched. */
    token: string;
}
/** What the caller must do after a key. */
export type EditorAction = {
    kind: 'none';
} | {
    kind: 'submit';
    text: string;
} | {
    kind: 'interrupt';
} | {
    kind: 'eof';
} | {
    kind: 'escape';
};
/** How the editor finds candidates for the token under the cursor. */
export interface EditorSources {
    /** The commands currently registered. */
    commands(): readonly CompletableCommand[];
    /** Path candidates for an `@` mention, as the completer produces them. */
    paths(token: string): CompletionResult;
    /**
     * Argument candidates for one command's first argument.
     *
     * `/plan off`, `/permission workspace-write`, `/model <id>` — the values a
     * command takes are the command's own knowledge, so the editor asks rather
     * than guessing. Absent or empty means the argument is free-form.
     * @param command - the command name without its slash.
     * @param typed - what has been typed of the argument so far.
     * @returns candidates to offer, best first.
     */
    commandArguments?(command: string, typed: string): readonly Candidate[];
}
/** A multi-line prompt editor. */
export declare class Editor {
    private readonly sources;
    private lines;
    private row;
    private column;
    private candidates;
    private selected;
    private readonly history;
    /** Where the caller is in history; equals `history.length` when not browsing. */
    private browsing;
    /** The buffer set aside while history is being browsed. */
    private stashed;
    constructor(sources: EditorSources);
    /** What to render. */
    get view(): EditorView;
    /** The buffer as one string. */
    get text(): string;
    /** Whether nothing has been typed. */
    get empty(): boolean;
    /**
     * Replace the buffer with earlier text, cursor at its end.
     *
     * This is recall-for-editing: the second Escape puts the previous submission
     * back so it can be corrected and resent.
     * @param text - the text to edit, possibly multi-line.
     */
    prefill(text: string): void;
    /** Submissions this session recorded, oldest first, for persistence. */
    get pastSubmissions(): readonly string[];
    /**
     * Preload history from an earlier session.
     *
     * Applied before any live submission, so recall starts where the last
     * session ended rather than empty.
     * @param entries - past submissions, oldest first.
     */
    seedHistory(entries: readonly string[]): void;
    /**
     * Apply one key.
     * @param key - the decoded keystroke.
     * @returns what the caller must do about it.
     */
    handle(key: Key): EditorAction;
    /** The line the cursor is on. */
    private line;
    /** Replace the cursor's line. */
    private setLine;
    /**
     * Insert text at the cursor, splitting lines on newlines.
     * @param text - the text to insert.
     * @returns always `none`; insertion never completes a read.
     */
    private insert;
    /**
     * Submit, or accept the highlighted candidate when the menu is open.
     * @returns the submission, or `none` when a candidate was taken instead.
     */
    private accept;
    /** Record a submission for history, collapsing an immediate repeat. */
    private remember;
    /**
     * Open the menu, or move through it when it is already open.
     * @returns always `none`.
     */
    private complete;
    /**
     * Replace the token under the cursor with the selected candidate.
     * @returns always `none`.
     */
    private take;
    /** Where the token under the cursor begins, in code points. */
    private tokenStart;
    /** The token under the cursor. */
    private token;
    /**
     * Recompute the candidate list for the token under the cursor.
     *
     * Recomputed on every edit rather than only on Tab, which is what makes the
     * menu appear as a command is typed instead of after a key that asks for it.
     */
    private refresh;
    /** Remove the character before the cursor, joining lines at a boundary. */
    private backspace;
    /** Remove the character after the cursor, joining lines at a boundary. */
    private forwardDelete;
    /** Move up a line, or back through history from the first line. */
    private moveUp;
    /** Move down a line, or forward through history from the last line. */
    private moveDown;
    /**
     * Step through history.
     * @param delta - -1 for older, 1 for newer.
     * @returns always `none`.
     */
    private recall;
    /** Move the cursor one position left, wrapping to the previous line. */
    private moveLeft;
    /** Move the cursor one position right, wrapping to the next line. */
    private moveRight;
    /**
     * Put the cursor at a column on the current line.
     * @param column - the target column.
     * @returns always `none`.
     */
    private jump;
    /** Drop everything after the cursor on this line. */
    private killLine;
    /** Drop everything before the cursor on this line. */
    private killInput;
    /** Move the cursor to the start of the word before it. */
    private wordLeft;
    /** Move the cursor past the end of the word after it. */
    private wordRight;
    /** Drop the word before the cursor. */
    private killWord;
    /**
     * Close the menu, or report Escape when there is none to close.
     * @returns `none` when a menu was dismissed, otherwise `escape`.
     */
    private cancel;
}

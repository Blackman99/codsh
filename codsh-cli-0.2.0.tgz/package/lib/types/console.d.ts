/**
 * The process-facing terminal, in two shapes.
 *
 * On a terminal this surface owns the keyboard AND the screen: raw mode, its own
 * key decoding, and an alternate-screen viewport ({@link Screen}) that holds the
 * transcript in a scrollback buffer of its own with the input box pinned below
 * it. That is what an inline completion menu, a multi-line prompt, and a session
 * that reads as its own space require — `readline` reports no lone Escape, draws
 * no menu, and decides for itself what Enter means.
 *
 * Off a terminal it is a line reader over `readline`, because a pipe has no
 * cursor to manage and every line in a script is a separate instruction. Both
 * shapes answer the same reads, which is what keeps piped runs and tests on the
 * same code path as a person typing.
 * @module codsh-cli/src/console
 */
import type { Key } from './keys.ts';
/** The output stream this surface writes to. */
export interface OutputStream extends NodeJS.WritableStream {
    readonly columns?: number;
    readonly rows?: number;
    readonly isTTY?: boolean;
}
/** The input stream this surface reads from. */
export interface InputStream extends NodeJS.ReadableStream {
    readonly isTTY?: boolean;
    setRawMode?(mode: boolean): unknown;
}
/** Where the cursor belongs among a region's rows. */
export interface RegionCursor {
    row: number;
    column: number;
}
/** Line input and output over one pair of process streams. */
export declare class TerminalConsole {
    private readonly input;
    private readonly output;
    private readonly rl;
    private readonly decoder;
    private readonly pending;
    private readonly waiters;
    private keyHandler;
    /** Keys decoded before any handler registered — type-ahead is never dropped. */
    private readonly earlyKeys;
    private escapeTimer;
    private ended;
    /** The viewport this surface owns on a terminal; absent off one. */
    private readonly screen;
    constructor(input: InputStream, output: OutputStream);
    /** Display columns available for one line, never below {@link MIN_COLUMNS}. */
    get columns(): number;
    /**
     * Columns content may be laid out for: one less than the width, because the
     * viewport wraps at that boundary. Markdown layout MUST use this figure — a
     * table laid out one column wider is refolded by the viewport, and its rows
     * shear apart.
     */
    get contentColumns(): number;
    /** Whether the output stream is a terminal. */
    get isTty(): boolean;
    /**
     * Whether this surface owns the keyboard.
     *
     * That needs both streams on a terminal: raw mode is what delivers a key
     * before its line, and there is no point managing rows on a stream with no
     * cursor.
     */
    get readsKeys(): boolean;
    /** Whether input has finished. */
    get finished(): boolean;
    /**
     * Register a handler for terminal window changes.
     * @param handler - called after each resize while registered.
     * @returns a disposer that removes it.
     */
    onResize(handler: () => void): () => void;
    /**
     * Take the viewport: the transcript and the prompt live on their own screen
     * from here, and the terminal keeps the buffer the person had.
     */
    enterScreen(): void;
    /**
     * Give the terminal back. Idempotent: every exit path calls it.
     */
    leaveScreen(): void;
    /** Whether this surface currently holds its own screen. */
    get owningScreen(): boolean;
    /**
     * Scroll the transcript inside the viewport.
     * @param delta - rows to move; negative goes back into history.
     */
    scrollBy(delta: number): void;
    /**
     * Set the notice shown while the transcript is scrolled back.
     * @param text - the styled line, or the empty string for none.
     */
    setScrollNotice(text: string): void;
    /**
     * Scroll the transcript by a whole viewport.
     * @param direction - -1 for back into history, 1 towards the tail.
     */
    scrollPage(direction: -1 | 1): void;
    /** Return to the tail of the transcript. */
    scrollToBottom(): void;
    /** Physical rows currently scrolled out of view; zero means at the tail. */
    get scrolledBy(): number;
    /**
     * Clear the transcript this session accumulated.
     *
     * On its own screen there is no shell scrollback to preserve, so this empties
     * the buffer the viewport shows rather than wiping a shared terminal.
     */
    clearScreen(): void;
    /**
     * Route decoded keys to a handler.
     * @param handler - receives every key while registered.
     * @returns a disposer that removes it.
     */
    onKey(handler: (key: Key) => void): () => void;
    /**
     * Decode one read and dispatch its keys.
     * @param chunk - the bytes the terminal delivered.
     */
    private onBytes;
    /** Hand one key to the handler, or hold it until one registers. */
    private deliver;
    /** Wait briefly for the rest of a held sequence, then resolve it as Escape. */
    private armEscapeFlush;
    /**
     * Hand one input line to the longest-waiting read, or queue it.
     * @param line - the line the reader produced.
     */
    private offer;
    /** Mark input finished and release every waiting read. */
    private end;
    /**
     * Keep one finished transcript line.
     *
     * On its own screen the line goes into the viewport's scrollback, which is
     * what lets the transcript scroll under a prompt that does not move. Off one
     * it is written straight out, because a pipe's reader wants exactly that.
     * @param line - the line, without its terminator.
     */
    write(line: string): void;
    /**
     * Replace the rows pinned below the transcript.
     *
     * This is the whole live area: an input box, a completion menu, a working
     * indicator, the status row. Off a terminal the call is ignored — a
     * redirected transcript must not collect frames of a box nobody can see.
     * @param rows - the rows to display, top to bottom.
     * @param cursor - where to leave the terminal cursor among them.
     * @param focus - whether the rows hold input focus, which is when the cursor
     *   shows. Parked anywhere else it reads as content colliding with it.
     */
    setRegion(rows: readonly string[], cursor: RegionCursor, focus?: boolean): void;
    /**
     * Keep one collapsible block: summary now, full form behind the toggle.
     *
     * Off a terminal only the summary is written — a pipe has no keys to toggle
     * with, and scripts want the digest.
     * @param summary - the collapsed lines.
     * @param full - the expanded lines.
     */
    appendFold(summary: readonly string[], full: readonly string[]): void;
    /**
     * Swap every collapsible block between summary and full form.
     * @returns false when there is nothing to toggle.
     */
    /**
     * Anchor a mouse selection at a terminal position.
     * @param row - terminal row, 1-based.
     * @param column - terminal column, 1-based.
     */
    mouseDown(row: number, column: number): void;
    /**
     * Extend the mouse selection to a terminal position.
     * @param row - terminal row, 1-based.
     * @param column - terminal column, 1-based.
     */
    mouseDrag(row: number, column: number): void;
    /**
     * Finish the mouse selection.
     * @returns the selected text, or undefined for a bare click.
     */
    mouseUp(): string | undefined;
    /**
     * Put text on the clipboard.
     *
     * Two channels, because neither is universal: OSC 52 reaches through SSH and
     * works wherever the terminal permits it, and the platform helper covers the
     * terminals that refuse the escape. `CODSH_CLIPBOARD` narrows it to `osc52`,
     * `system`, or `off` — tests use `osc52` so a run never touches the real
     * clipboard.
     * @param text - the plain text to copy.
     * @returns whether a copy was attempted at all.
     */
    copyText(text: string): boolean;
    /**
     * Make the last `count` written lines a collapsible block after the fact.
     *
     * Screen-only on purpose: a pipe already carries the full text, and a
     * summary would subtract from it.
     * @param count - how many trailing lines the block owns.
     * @param summary - the collapsed lines, already styled.
     */
    foldRecent(count: number, summary: readonly string[]): void;
    toggleFolds(): boolean;
    /** Return every block to its summary. */
    collapseFolds(): void;
    /** Take the pinned rows down, leaving the transcript alone. */
    clearRegion(): void;
    /** Ring the terminal bell; a pipe gets nothing to beep with. */
    bell(): void;
    /**
     * Set the terminal window title.
     * @param title - the title text; control bytes are the terminal's to reject.
     */
    setTitle(title: string): void;
    /**
     * Read one line from a piped stream.
     *
     * Only the non-terminal shape reads this way; with the keyboard owned, input
     * arrives as keys and the caller drives an editor instead.
     * @param signal - aborts the pending read.
     * @returns the line, or undefined when input ended or the read aborted.
     */
    readLine(signal?: AbortSignal): Promise<string | undefined>;
    /** Restore the terminal and stop reading. */
    close(): void;
    /**
     * Write one line to the terminal the person keeps, not to our viewport.
     *
     * The exit summary is what needs this: the session's own screen disappears
     * with it, so the few facts worth keeping — the session id, what it cost —
     * have to land in the buffer that survives.
     * @param line - the line, without its terminator.
     */
    writeAfterScreen(line: string): void;
}

/**
 * The working indicator: one rewritable line saying the agent is busy, how long
 * it has been, and which key stops it.
 *
 * It occupies the console's single live line, so the transcript above it stays
 * append-only and the indicator never survives into a redirected transcript.
 * @module codsh-cli/src/spinner
 */
import type { Theme } from './theme.ts';
/** The console surface a spinner drives. */
export interface LiveSurface {
    setLive(text: string | undefined): void;
    readonly isTty: boolean;
}
/** Formats the indicator's text for one tick. */
export interface SpinnerLabel {
    /** What the agent is doing, e.g. `working`. */
    verb: string;
    /** Key that cancels, named for the surface that can read it. */
    interrupt: string;
    /** Live extra segment, read each tick — e.g. tokens spent so far. */
    detail?: () => string | undefined;
}
/**
 * Render one tick of the indicator.
 * @param frame - the frame index, taken modulo the frame count.
 * @param elapsedMs - milliseconds since the work started.
 * @param label - the verb and interrupt key to name.
 * @param theme - styling for the frame and the hint.
 * @returns the line to display.
 */
export declare function spinnerText(frame: number, elapsedMs: number, label: SpinnerLabel, theme: Theme): string;
/** Drives the working indicator for as long as the agent is busy. */
export declare class Spinner {
    private readonly surface;
    private readonly theme;
    private readonly label;
    /** Injected so tests advance time without waiting for it. */
    private readonly now;
    private timer;
    private frame;
    private startedAt;
    constructor(surface: LiveSurface, theme: Theme, label: SpinnerLabel, 
    /** Injected so tests advance time without waiting for it. */
    now?: () => number);
    /** Whether the indicator is running. */
    get running(): boolean;
    /**
     * Start the indicator, or do nothing when it is already running or the
     * surface has no cursor to rewrite.
     *
     * The clock keeps running across a pause: the elapsed figure is the whole
     * turn's, and an indicator that restarted from zero at every tool call would
     * report each step instead.
     */
    start(): void;
    /** Hide the indicator without forgetting when the turn began. */
    pause(): void;
    /** Stop the indicator: the turn is over, and the next one starts at zero. */
    stop(): void;
    /** Paint the current frame. */
    private draw;
}

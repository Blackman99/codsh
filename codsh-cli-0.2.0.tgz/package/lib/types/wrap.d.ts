/**
 * Display-width wrapping for styled text.
 *
 * Inside the alternate screen the terminal no longer wraps for us: a transcript
 * line longer than the viewport must be broken into rows before it is painted,
 * or it would overwrite the row below. The lines being broken are already
 * styled, so a naive split would cut an escape sequence in half and leak
 * gibberish — and a continuation row would lose the colour its first half set.
 * @module codsh/src/wrap
 */
/**
 * Break one styled line into rows no wider than `columns` display columns.
 *
 * Styles carry across the break: each continuation row re-opens whatever was
 * active where the cut fell, and every row that opened a style closes it.
 * @param text - the styled line, without a terminator.
 * @param columns - display columns available per row.
 * @returns the rows, at least one (an empty line yields one empty row).
 */
export declare function wrapStyled(text: string, columns: number): string[];
/**
 * Wrap many lines, keeping their order.
 * @param lines - styled lines.
 * @param columns - display columns per row.
 * @returns the physical rows they occupy.
 */
export declare function wrapAll(lines: readonly string[], columns: number): string[];

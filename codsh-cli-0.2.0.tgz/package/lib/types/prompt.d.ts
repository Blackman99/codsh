/**
 * The prompt as the person sees it: an input box, a completion menu, a working
 * indicator, a status row, and — when a decision is being asked — a selection
 * widget in the box's place.
 *
 * This is where the two input shapes meet. On a terminal it drives the editor
 * from decoded keys and owns the bottom region; off one it reads lines from the
 * pipe and draws nothing. Callers ask for the next submission either way.
 * @module codsh-cli/src/prompt
 */
import type { TerminalConsole } from './console.ts';
import type { EditorSources } from './editor.ts';
import type { SelectOutcome, SelectSpec } from './selector.ts';
import type { Theme } from './theme.ts';
/** What the prompt reports to its owner. */
export interface PromptHandlers {
    /** Ctrl-C: stop the work, or leave. */
    interrupt(): void;
    /** Escape with nothing of the prompt's own to dismiss: stop the work. */
    escape(): void;
    /** Ctrl-D on an untouched prompt: leave. */
    eof(): void;
    /** Shift-Tab: cycle the session's mode. */
    shiftTab?(): void;
    /** Ctrl-O: show the last clipped tool output in full. */
    expandOutput?(): void;
}
/** Drives the input box and answers reads and selections. */
export declare class Prompt {
    private readonly console;
    private readonly theme;
    private readonly handlers;
    /** Dim text shown inside an empty box. */
    private readonly placeholder?;
    private readonly editor;
    private pending;
    private select_;
    /**
     * Submissions made before anything asked for them.
     *
     * Typing while the agent works — or in the instant before a read begins — must
     * not be lost; the queue is what a line reader provides for free.
     */
    private readonly queued;
    /** The working indicator shown under the box. */
    private hint;
    /** A short-lived notice that borrows the hint row, e.g. the copy toast. */
    private flash;
    private flashTimer;
    /** The always-current session facts shown as the region's last row. */
    private status;
    /** The assistant line still arriving, shown above the box. */
    private streaming;
    /** Frame styling for the current mode, e.g. plan mode's accent. */
    private accent;
    /** Whether a read is outstanding, which decides where a submission goes. */
    private reading;
    /** Wheel rows accumulated this tick, painted once — scrolling per event janks. */
    private pendingScroll;
    private scrollFlushQueued;
    /**
     * Whether the interactive session is running, which is when the box is worth
     * drawing. The box stays up while the agent works — typing ahead must be
     * visible, and a prompt that vanishes for every turn reads as losing focus —
     * so this is session-scoped, not read-scoped.
     */
    private engaged;
    constructor(console: TerminalConsole, theme: Theme, sources: EditorSources, handlers: PromptHandlers, 
    /** Dim text shown inside an empty box. */
    placeholder?: string | undefined);
    /** The editor's submission history, for persistence. */
    get history(): readonly string[];
    /**
     * Preload history from an earlier session.
     * @param entries - past submissions, oldest first.
     */
    seedHistory(entries: readonly string[]): void;
    /** Whether the box holds no typed text. */
    get empty(): boolean;
    /**
     * Show the input box from now on, independent of an outstanding read.
     * @param engaged - whether the interactive session is running.
     */
    setEngaged(engaged: boolean): void;
    /**
     * Put earlier text back into the box for editing.
     * @param text - the text to edit.
     */
    prefill(text: string): void;
    /**
     * Set the working indicator under the box.
     * @param text - the text, or undefined to drop the row.
     */
    setHint(text: string | undefined): void;
    /**
     * Show a notice on the hint row briefly, then give the row back.
     *
     * The hint row belongs to the working indicator, which repaints itself
     * continuously — a notice written through setHint would last one tick. The
     * flash outranks the hint until its moment passes.
     * @param text - the styled notice.
     */
    setFlash(text: string): void;
    /**
     * Set the status row, the region's always-current last line.
     * @param text - the styled row, or undefined to drop it.
     */
    setStatus(text: string | undefined): void;
    /**
     * Set the frame accent, which is how a mode shows on the box itself.
     * @param accent - the styling, or undefined for the default frame.
     */
    setAccent(accent: ((text: string) => string) | undefined): void;
    /**
     * Set the assistant line currently arriving, shown above the box.
     * @param text - the partial line, or undefined when none is open.
     */
    setStreaming(text: string | undefined): void;
    /**
     * Write one finished transcript line above the region.
     * @param line - the line to keep.
     */
    write(line: string): void;
    /**
     * Wait for the next submitted text.
     * @param signal - abandons the read, which an aborted tool call does.
     * @returns the text, or undefined when input ended or the read was abandoned.
     */
    read(signal?: AbortSignal): Promise<string | undefined>;
    /**
     * Put one decision to the keyboard as an arrow-key selection.
     *
     * Only the terminal shape can offer this; the caller keeps a line-based
     * fallback for pipes, where the selection keys cannot arrive.
     * @param spec - the question and its options.
     * @param signal - cancels the selection, which an aborted tool call does.
     * @returns how the person decided.
     */
    select(spec: SelectSpec, signal?: AbortSignal): Promise<SelectOutcome>;
    /** Take the region down, so what follows lands at the bottom of the screen. */
    clear(): void;
    /**
     * Apply one key: control keys to the owner, a selection's keys to the
     * selector, everything else to the editor.
     * @param key - the decoded keystroke.
     */
    private onKey;
    /** Recompose and redraw the bottom region. */
    private render;
}

/**
 * The terminal's user-questions provider: it renders each question as a
 * numbered menu, reads one line per question, and encodes the answer.
 *
 * A question may offer options, free text, or both. Selecting by number
 * answers with that option's label; typing anything else answers as `custom`,
 * which is the encoding `ask_user_question` documents for an "Other" reply.
 * @module codsh-cli/src/questions
 */
import type { AskUserQuestionAnswer, AskUserQuestionAnswerItem, AskUserQuestionItem, AskUserQuestionRequest } from '@deepseek-ai/dsh-user-questions';
import type { SelectOutcome, SelectSpec } from './selector.ts';
import type { Theme } from './theme.ts';
/** Puts one selection to the keyboard; absent on a pipe, which types instead. */
export type SelectAsk = (spec: SelectSpec, signal?: AbortSignal) => Promise<SelectOutcome>;
/** Reads one answer from the person. */
export interface LineReader {
    /**
     * Read one submission.
     * @param signal - aborts the read when the owning tool call is cancelled.
     * @returns the answer, or undefined when input ended or the read aborted.
     */
    read(signal?: AbortSignal): Promise<string | undefined>;
}
/**
 * Parse a selection line against one question's options.
 *
 * A comma-separated list of numbers selects those options; a multi-select
 * question accepts several, a single-select takes the first. Anything that is
 * not a valid index becomes the free-text answer.
 * @param line - the line the person typed.
 * @param question - the question being answered.
 * @returns the encoded answer for this question.
 */
export declare function encodeAnswer(line: string, question: AskUserQuestionItem): AskUserQuestionAnswerItem;
/**
 * Render one question as the lines shown above its prompt.
 * @param question - the question to render.
 * @param theme - styling for the heading and option list.
 * @returns the lines to print.
 */
export declare function questionLines(question: AskUserQuestionItem, theme: Theme): string[];
/** Answers `ask_user_question` from the terminal. */
export declare class TerminalQuestions {
    private readonly reader;
    private readonly theme;
    private readonly write;
    /** The arrow-key selection, offered only where keys can arrive. */
    private readonly select?;
    constructor(reader: LineReader, theme: Theme, write: (line: string) => void, 
    /** The arrow-key selection, offered only where keys can arrive. */
    select?: SelectAsk | undefined);
    /**
     * Put every question in one request to the person, in order.
     * @param request - the questions, owner agent, and abort signal.
     * @returns one answer per question, in request order.
     */
    ask(request: AskUserQuestionRequest): Promise<AskUserQuestionAnswer>;
    /**
     * Put one question to the person.
     * @param question - the question.
     * @param signal - aborts with the owning tool call.
     * @returns the encoded answer.
     */
    private one;
}

/**
 * Markdown as terminal lines.
 *
 * A model answers in Markdown, and printing the source verbatim leaves the
 * reader to parse `**` and fences by eye. This renders the constructs that
 * actually change how an answer reads — headings, lists, quotes, emphasis,
 * inline code, and fenced blocks — and leaves everything else exactly as it
 * arrived. Anything unrecognised must survive unchanged: mangling prose to
 * decorate it is worse than not decorating it.
 * @module codsh-cli/src/markdown
 */
import type { SyntaxTheme, Theme } from './theme.ts';
/**
 * Colour one line of code by token class.
 *
 * A heuristic, not a parser: it has no state between lines, so a string or
 * comment spanning several lines is coloured only on the line where it opens.
 * Getting that wrong costs a colour, never the text — every branch reproduces
 * its input exactly.
 * @param line - the code line.
 * @param syntax - styling per token class.
 * @returns the coloured line.
 */
export declare function highlightCode(line: string, syntax: SyntaxTheme): string;
/**
 * Style the inline constructs of one line of prose.
 * @param text - the line, with block syntax already stripped.
 * @param theme - styling for emphasis, code spans, and link targets.
 * @returns the styled line.
 */
export declare function renderInline(text: string, theme: Theme): string;
/**
 * A Markdown renderer that consumes one line at a time.
 *
 * Stateful because fencing is: whether a line is code depends on a fence seen
 * earlier, so a renderer that forgot between lines would style the inside of a
 * code block as prose. This is the form streaming needs — a line can be
 * rendered the moment it completes, without waiting for the whole answer.
 */
export interface MarkdownStream {
    /**
     * Render one input line.
     * @param line - the line, without its terminator.
     * @returns the output lines, which may be none (a fence delimiter, or a table
     *   row held until the table ends).
     */
    line(line: string): string[];
    /**
     * Close the stream, rendering anything still held back.
     *
     * A table is only recognisable once its delimiter row arrives, so its rows
     * buffer; an answer that ends mid-table must still show them.
     * @returns the remaining output lines.
     */
    flush(): string[];
    /** Whether the renderer is currently inside a fenced block. */
    readonly inCode: boolean;
}
/**
 * Build a line-at-a-time Markdown renderer.
 * @param theme - styling for every construct.
 * @param columns - display columns available, read per table; absent means
 *   unconstrained. A table wider than this prints as its source lines.
 * @returns the renderer, carrying its own fence and table state.
 */
export declare function createMarkdownStream(theme: Theme, columns?: () => number): MarkdownStream;
/**
 * Render a whole Markdown answer as terminal lines.
 * @param text - the answer, as the model produced it.
 * @param theme - styling for every construct.
 * @returns the output lines, blocks included.
 */
export declare function renderMarkdown(text: string, theme: Theme): string[];

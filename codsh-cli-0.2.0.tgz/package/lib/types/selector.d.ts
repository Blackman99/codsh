/**
 * The arrow-key selection widget: approvals, questions, and any other choice a
 * person makes by moving a marker rather than by typing an answer.
 *
 * Pure state, like the editor: keys in, a verdict and rows out. One widget
 * serves single-select, multi-select, and shortcut keys, because three slightly
 * different pickers is how the same bug ships three times.
 * @module codsh-cli/src/selector
 */
import type { Key } from './keys.ts';
import type { Theme } from './theme.ts';
/** One choice on offer. */
export interface SelectOption {
    /** What the choice is, shown as its row. */
    label: string;
    /** Extra context shown dimly beside the label. */
    detail?: string;
    /** Single key that picks this option outright (e.g. `y`). */
    shortcut?: string;
}
/** What a selection asks. */
export interface SelectSpec {
    /** The question, shown above the options. */
    title: string;
    options: readonly SelectOption[];
    /** Whether several options may be chosen; Space toggles, Enter confirms. */
    multi?: boolean;
    /** Label for a trailing "type your own" row; absent offers none. */
    custom?: string;
}
/** How one selection ended. */
export type SelectOutcome = {
    kind: 'chosen';
    indices: number[];
} | {
    kind: 'custom';
} | {
    kind: 'cancelled';
};
/** What a key did to the selection. */
export type SelectorStep = {
    kind: 'pending';
} | {
    kind: 'done';
    outcome: SelectOutcome;
};
export declare class Selector {
    private readonly spec;
    private selected;
    private readonly checked;
    constructor(spec: SelectSpec);
    /** How many rows the widget offers, the custom row included. */
    private get count();
    /** Whether a row index is the custom "type your own" row. */
    private isCustom;
    /**
     * Apply one key.
     * @param key - the decoded keystroke.
     * @returns whether the selection settled, and how.
     */
    handle(key: Key): SelectorStep;
    /**
     * Resolve a typed character: a digit jumps, a shortcut picks, Space toggles.
     * @param text - what was typed.
     * @returns whether the selection settled.
     */
    private typed;
    /**
     * Settle on a row.
     * @param index - the row accepted.
     * @returns the settled step.
     */
    private accept;
    /**
     * Render the widget.
     * @param theme - styling for the marker, shortcuts, and details.
     * @param columns - display columns available per row.
     * @returns the rows, title first.
     */
    view(theme: Theme, columns: number): string[];
    /**
     * One option's label with its number and shortcut.
     * @param option - the option to label.
     * @param theme - styling for the shortcut.
     * @returns the label text.
     */
    private label;
    /**
     * One rendered row.
     * @param index - the row's index.
     * @param label - the row's label, already styled.
     * @param detail - dim context beside it.
     * @param theme - styling for the marker and detail.
     * @param columns - display columns available.
     * @returns the row text.
     */
    private row;
}

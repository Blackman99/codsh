/**
 * The terminal app's command-line provider: it parses the optional task
 * positional, the session-continuation flags, the preset override, and
 * `--help`, then publishes {@link CODING_CLI_STARTUP_SERVICE}. The runner is an
 * ordinary consumer whose lazy config waits for that service.
 * @module codsh-cli/startup
 */
import type { Context } from '@deepseek-ai/cordis';
/** Stable Cordis plugin name. */
export declare const name = "coding-cli-startup";
/** Services required before the invocation can be resolved. */
export declare const inject: string[];
/** Service provided by this plugin and injected by the terminal runner. */
export declare const CODING_CLI_STARTUP_SERVICE = "codingCliStartup";
/** What the runner row reads from {@link CODING_CLI_STARTUP_SERVICE}. */
export interface CodingCliStartupValues {
    /** Opening task text, or the empty string when the session starts at the prompt. */
    task: string;
    /** Session to reopen: an explicit id, `'latest'` for `--continue`, or the empty string for a new session. */
    resume: string;
    /** Preset id overriding the roster default, or the empty string to accept it. */
    preset: string;
    /** Render the answer and exit rather than entering the interactive loop. */
    print: boolean;
}
/**
 * Parse and provide this invocation as an ordinary Cordis service. On `--help`
 * and on a usage error nothing is provided, so the runner never mounts.
 * @param ctx - plugin context carrying the command line.
 */
export declare function apply(ctx: Context): void;

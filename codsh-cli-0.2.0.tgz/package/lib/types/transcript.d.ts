/**
 * Session log to terminal lines. One appended {@link SessionEvent} renders to
 * zero or more finished lines; the surface never rewrites a line it has
 * printed, so the transcript scrolls like a shell history.
 *
 * Tool cards come from the registered presenters rather than from tool names:
 * a tool declares its own render intent, and this module switches on the
 * resulting `card` tag.
 * @module codsh-cli/src/transcript
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { ToolCallView, ToolResult, ToolResultView } from '@deepseek-ai/dsh-tools';
import type { Theme } from './theme.ts';
/** The registered presenters, resolved against the agent's scope by the caller. */
export interface ToolPresenters {
    /**
     * Render intent for a pending call.
     * @param name - the tool the model called.
     * @param args - the parsed call arguments.
     * @returns the declared view, or undefined for the generic fallback.
     */
    call(name: string, args: unknown): ToolCallView | undefined;
    /**
     * Render intent for a completed call.
     * @param name - the tool the model called.
     * @param args - the parsed call arguments.
     * @param result - the completed outcome.
     * @returns the declared view, or undefined for the generic fallback.
     */
    result(name: string, args: unknown, result: ToolResult): ToolResultView | undefined;
}
/** What the renderer needs to know about the surface it writes to. */
export interface TranscriptOptions {
    theme: Theme;
    /** Display columns available for one line. */
    columns: number;
    /** Session workspace, stripped from absolute paths so cards stay short. */
    cwd: string;
}
/** Renders one session's appended events as terminal lines. */
export declare class Transcript {
    private readonly options;
    private readonly presenters;
    private readonly calls;
    /** The full form of the event just rendered, when its body was collapsed. */
    private fold;
    constructor(options: TranscriptOptions, presenters: ToolPresenters);
    /**
     * Shorten an absolute path inside the workspace to a workspace-relative one.
     * @param path - the model-facing path a card carries.
     * @returns the display path.
     */
    private relative;
    /**
     * Shorten every workspace path a presenter embedded in free text.
     *
     * A title is prose the tool composed (`Write /abs/path`), so the path inside
     * it needs the same shortening as a structured `locations` entry.
     * @param text - the presenter-supplied line.
     * @returns the line with workspace-rooted paths made relative.
     */
    private relativizeIn;
    /**
     * Paths worth appending to a title that may already name them.
     * @param title - the presenter's title, already relativized.
     * @param paths - the relativized paths the card covers.
     * @returns the paths the title does not mention, joined for display.
     */
    private extraPaths;
    /**
     * Render one appended event.
     * @param event - the event exactly as recorded.
     * @returns the lines to append to the transcript, empty when the event shows nothing.
     */
    render(event: SessionEvent): string[];
    /**
     * Render a pending call as its declared card.
     * @param callId - correlation id, remembered until the result pairs with it.
     * @param name - the tool the model called.
     * @param rawArguments - the unparsed arguments JSON the model produced.
     * @returns the pending card's lines.
     */
    private renderCall;
    /**
     * Render a completed call, pairing it with the call this transcript recorded.
     * @param data - the `tool/result` payload.
     * @returns the completed card's lines.
     */
    private renderResult;
    /**
     * The expanded form of the lines {@link render} just returned, when that
     * event's body was collapsed — the whole event re-rendered without its cap,
     * because a fold swaps entire blocks, not just the clipped tail. The full
     * body is kept from the render itself: what a tool truncated before
     * returning is upstream of the log and unrecoverable everywhere.
     * @returns the full lines, or undefined when nothing was collapsed.
     */
    takeFold(): string[] | undefined;
    /**
     * Render one completed call's status suffix and body from its declared view.
     * @param view - the result view, absent when no presenter answered.
     * @param block - the model-facing result block, used by the generic fallback.
     * @returns the suffix, the (possibly capped) body, and — when the cap dropped
     *   lines, or a bodiless card withheld content — the full body for Ctrl-O.
     */
    private outcome;
    /**
     * Flatten a result's content blocks to displayable text.
     * @param content - the result content blocks.
     * @returns the joined text.
     */
    private resultText;
    /**
     * Ask a call presenter for its view, absorbing a throwing presenter.
     * @param name - the tool the model called.
     * @param args - the parsed call arguments.
     * @returns the view, or undefined to fall back to the generic line.
     */
    private safeCall;
    /**
     * Ask a result presenter for its view, absorbing a throwing presenter.
     * @param pending - the recorded call this result pairs with.
     * @param content - the model-facing result content.
     * @param isError - whether the executor reported a failure.
     * @param meta - the tool's private presentation payload, when it attached one.
     * @returns the view, or undefined to fall back to the generic card.
     */
    private safeResult;
}

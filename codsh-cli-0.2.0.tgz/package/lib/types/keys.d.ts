/**
 * Terminal bytes to key events.
 *
 * Owning the keyboard is what an input box costs: `readline` cannot report a
 * lone Escape, cannot be asked to draw a completion menu, and decides for itself
 * what Enter means. Decoding here is the price of deciding those things.
 *
 * The decoder is incremental because a terminal splits sequences across reads:
 * an arrow key can arrive as `ESC`, then `[`, then `A`. Anything it cannot yet
 * resolve is held until the next byte rather than guessed at.
 * @module codsh-cli/src/keys
 */
/** What one keystroke means to the editor. */
export type Key = {
    kind: 'text';
    text: string;
} | {
    kind: 'enter';
} | {
    kind: 'newline';
} | {
    kind: 'tab';
} | {
    kind: 'backspace';
} | {
    kind: 'delete';
} | {
    kind: 'up';
} | {
    kind: 'down';
} | {
    kind: 'left';
} | {
    kind: 'right';
} | {
    kind: 'home';
} | {
    kind: 'end';
} | {
    kind: 'escape';
} | {
    kind: 'interrupt';
} | {
    kind: 'eof';
} | {
    kind: 'kill-line';
} | {
    kind: 'kill-input';
} | {
    kind: 'kill-word';
} | {
    kind: 'word-left';
} | {
    kind: 'word-right';
} | {
    kind: 'shift-tab';
} | {
    kind: 'clear-screen';
} | {
    kind: 'expand-output';
} | {
    kind: 'page';
    direction: -1 | 1;
} | {
    kind: 'scroll';
    lines: number;
} | {
    kind: 'scroll-end';
} | {
    kind: 'paste';
    text: string;
} | {
    kind: 'mouse-down';
    row: number;
    column: number;
} | {
    kind: 'mouse-drag';
    row: number;
    column: number;
} | {
    kind: 'mouse-up';
    row: number;
    column: number;
};
/** Decodes terminal bytes into keys, holding partial sequences between reads. */
export declare class KeyDecoder {
    private held;
    private pasting;
    private pasted;
    /**
     * Feed one read's worth of input.
     * @param chunk - the bytes as text.
     * @returns the keys this read completed, in order.
     */
    push(chunk: string): Key[];
    /** Whether bytes are held back awaiting the rest of a sequence. */
    get pending(): boolean;
    /**
     * Resolve a held Escape that no further byte arrived for.
     *
     * `ESC` alone and the first byte of `ESC [ A` are the same byte, so the two can
     * only be told apart by what follows — or by nothing following. The caller arms
     * a short timer after each read and calls this when it expires: an arrow key
     * split across reads completes long before that, and a key pressed by itself
     * never completes at all.
     * @returns the Escape key, or nothing when the held bytes are a real prefix.
     */
    flush(): Key[];
    /**
     * Resolve the held bytes into one key, if they are enough.
     * @returns the keys produced, or undefined when more bytes are needed.
     */
    private take;
    /**
     * Collect bracketed-paste content up to its end marker.
     * @returns the paste key once complete, otherwise undefined.
     */
    private takePasted;
}
/** Ask the terminal to wrap pasted text in markers. */
export declare const ENABLE_PASTE_MARKERS = "\u001B[?2004h";
/** Stop the terminal wrapping pasted text, restoring what it did before. */
export declare const DISABLE_PASTE_MARKERS = "\u001B[?2004l";

/**
 * Custom slash commands from Markdown files.
 *
 * A file named `review.md` under a commands root becomes `/review`: its
 * frontmatter `description` labels it in the completion menu, and its body is
 * the prompt submitted when the command runs — with `$ARGUMENTS` replaced by
 * whatever followed the name. They are canned prompts, not handlers: execution
 * goes through the same submission path as a typed message.
 * @module codsh-cli/src/custom-commands
 */
/** One loaded command. */
export interface CustomCommand {
    /** The name typed after the slash. */
    name: string;
    /** Menu label, from frontmatter or a fallback naming the file. */
    description: string;
    /** The prompt body, with `$ARGUMENTS` placeholders intact. */
    template: string;
}
/** What loading produced: the commands, and what was skipped and why. */
export interface CustomCommandLoad {
    commands: CustomCommand[];
    /** One line per skipped file, for the surface to show once at startup. */
    warnings: string[];
}
/**
 * Parse one command file: optional `---` frontmatter with a `description`
 * line, then the prompt body.
 * @param source - the file content.
 * @returns the description (empty when absent) and the body.
 */
export declare function parseCommandFile(source: string): {
    description: string;
    body: string;
};
/**
 * Fill a template with the typed arguments.
 * @param template - the prompt body.
 * @param typed - what followed the command name, possibly empty.
 * @returns the prompt to submit: placeholders replaced, or the arguments
 *   appended when the template never asked for them.
 */
export declare function expandTemplate(template: string, typed: string): string;
/**
 * Load every command under the given roots, later roots shadowing earlier.
 *
 * A missing root is normal (most setups define no custom commands); an
 * unreadable or misnamed file is a warning, never a failed startup — a broken
 * canned prompt should cost that prompt, not the session.
 * @param roots - directories to scan, lowest precedence first.
 * @param taken - names already registered, which a file cannot shadow.
 * @returns the loaded commands and the warnings to show once.
 */
export declare function loadCustomCommands(roots: readonly string[], taken: ReadonlySet<string>): Promise<CustomCommandLoad>;

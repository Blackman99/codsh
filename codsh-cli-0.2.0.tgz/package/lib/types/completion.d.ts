/**
 * Completion sources for the prompt: slash commands, and workspace files behind
 * an `@` mention.
 *
 * Bare prose never completes. A sentence headed for the model would be rewritten
 * by a completer guessing at it, so a path has to be asked for — `@` is that
 * request, and it is also what makes the mention legible to the model, which
 * reads the file with its own tools.
 *
 * Matching is fuzzy, not prefix: the person knows a fragment of the name, not
 * where in the path it starts. A prefix match still ranks first, so the fuzzy
 * fallback never steals an exact intention.
 * @module codsh-cli/src/completion
 */
/** One completable command: its name without the slash, and what it does. */
export interface CompletableCommand {
    name: string;
    description: string;
}
/** `readline`'s completer result: the candidates, and the substring they replace. */
export type CompletionResult = [completions: string[], substring: string];
/**
 * Score `needle` against `hay` as a fuzzy subsequence.
 *
 * Consecutive hits and hits on a boundary (start, or after a separator) score
 * higher, which is what ranks `src/idx` matches the way a person expects. A
 * needle that is not a subsequence scores nothing at all.
 * @param needle - what was typed, matched case-insensitively.
 * @param hay - the candidate.
 * @returns the score, or undefined when it does not match.
 */
export declare function fuzzyScore(needle: string, hay: string): number | undefined;
/** Drop the cached workspace walk, so a test controls what the next Tab sees. */
export declare function resetFileIndex(): void;
/**
 * Build the completer for one session.
 *
 * The command list is read on each use rather than captured, because a command
 * registry is scoped and changes with the session's mode — plan mode alone adds
 * and removes one.
 * @param commands - reads the currently registered commands.
 * @param cwd - the workspace `@` mentions resolve against.
 * @returns a completer over the word under the cursor.
 */
export declare function createCompleter(commands: () => readonly CompletableCommand[], cwd: string): (line: string) => CompletionResult;

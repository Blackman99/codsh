/**
 * The opening banner: what answered, where, and which keys matter.
 * @module codsh-cli/src/banner
 */
import type { Theme } from './theme.ts';
/** What the banner reports about the composed session. */
export interface BannerFacts {
    /** Model route answering this session. */
    model: string;
    /** Composed preset, absent when the deployment composes no roster. */
    preset?: string | undefined;
    /** Session workspace. */
    cwd: string;
    /** Checked-out branch, absent outside a repository. */
    branch?: string | undefined;
    /** Session identity, so a person can resume this exact conversation later. */
    session: string;
    /** Whether Escape can reach the surface; decides which interrupt is named. */
    readsKeys: boolean;
    /** Whether the transcript replayed a resumed conversation above the banner. */
    resumed: boolean;
}
/**
 * Render the opening banner.
 * @param facts - what to report.
 * @param theme - styling for the frame and the detail lines.
 * @param columns - display columns available; a narrow terminal loses the frame.
 * @returns the lines to print, ending with a blank separator.
 */
export declare function bannerLines(facts: BannerFacts, theme: Theme, columns: number): string[];

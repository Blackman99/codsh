/**
 * `codsh` — the interactive terminal surface. The bundle
 * patch rides over dsh-base without Host, HTTP, or browser plugins; this runner
 * composes one Agent from the roster's preset, renders its session log to the
 * terminal, answers approvals and questions from the keyboard, and drives the
 * conversation until the person leaves.
 *
 * The surface shares the process with the Agent, so it reads `ctx.agents`
 * directly. The API gateway exists to carry out-of-process clients and would
 * add a serialization hop with no reader on the other side.
 *
 * @module codsh
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Stable Cordis plugin name. */
export declare const name = "coding-cli-runner";
/** Core services required before the surface can compose an agent. */
export declare const inject: string[];
/** Plugin config: the invocation resolved from this app's injected provider service. */
export interface Config {
    /** Opening task, or the empty string to start at the prompt. */
    task: string;
    /** Session to reopen: an id, `'latest'`, or the empty string for a new session. */
    resume: string;
    /** Preset id overriding the roster default, or the empty string to accept it. */
    preset: string;
    /** Render the answer to `task` and exit rather than entering the prompt. */
    print: boolean;
    /** Ring the terminal bell when a decision waits or a long turn ends. */
    bell: boolean;
    /** How long a `!` passthrough command may run before it is killed. */
    bangTimeoutMs: number;
    /** Output lines a `!` passthrough keeps before summarizing the rest. */
    bangOutputLines: number;
}
export declare const Config: z<Config>;
/** The process streams the surface binds to; tests substitute captures. */
export declare const internals: {
    input: NodeJS.ReadableStream;
    output: NodeJS.WriteStream;
};
/**
 * Mount the interactive terminal surface.
 * @param ctx - plugin context carrying core services and the launcher-provided exit request.
 * @param config - validated invocation config.
 */
export declare function apply(ctx: Context, config: Config): void;

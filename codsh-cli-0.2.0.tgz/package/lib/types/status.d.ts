/**
 * The status readout shown with the prompt: what model and composition answer,
 * where the session is, and how much context is left.
 *
 * Every figure is read from a durable projection or a logged fold rather than
 * tracked here, so a resumed session reports the same numbers it ended with.
 * @module codsh-cli/src/status
 */
import type { ContextPressureProjection, TokenUsageProjection } from '@deepseek-ai/dsh-token-meter/client';
import type { Theme } from './theme.ts';
/** Everything one status line reports. */
export interface StatusFacts {
    /** Model route answering this session. */
    model: string;
    /** Composed preset, absent when the deployment composes no roster. */
    preset?: string | undefined;
    /** Permission preset name, absent when none is composed. */
    permission?: string | undefined;
    /** Whether plan mode is holding. */
    planMode: boolean;
    /** Session workspace. */
    cwd: string;
    /** Checked-out branch, absent outside a repository. */
    branch?: string | undefined;
    /** Cumulative provider usage, absent before the first reported request. */
    usage?: TokenUsageProjection | undefined;
    /** Context occupancy, absent before the first reported request. */
    context?: ContextPressureProjection | undefined;
}
/**
 * Abbreviate a token count the way a status line wants it: exact while small,
 * one decimal at thousands, whole at millions.
 * @param tokens - the count to render.
 * @returns the abbreviated figure.
 */
export declare function formatTokens(tokens: number): string;
/**
 * Total tokens a session has spent across every bucket.
 *
 * The four buckets are disjoint by contract — reasoning already sits inside
 * output — so a plain sum is the session total.
 * @param usage - cumulative usage, or undefined before any request.
 * @returns the total, or undefined when nothing is recorded.
 */
export declare function totalTokens(usage: TokenUsageProjection | undefined): number | undefined;
/**
 * Percentage of the context window still free for the next request.
 *
 * `projectedTokens` is what the NEXT prompt would cost, which is the figure a
 * person deciding whether to keep going needs; it also moves the instant a
 * compaction shadows a span, where the raw sample cannot.
 * @param context - the occupancy projection.
 * @returns whole percent remaining, or undefined without both figures.
 */
export declare function contextLeftPercent(context: ContextPressureProjection | undefined): number | undefined;
/**
 * Shorten a path for display, collapsing the home directory to `~`.
 * @param path - the absolute path.
 * @param home - the home directory to collapse; defaults to the real one.
 * @returns the display path.
 */
export declare function displayPath(path: string, home?: string): string;
/**
 * Read the checked-out branch by walking up to the repository's `HEAD`.
 *
 * Read rather than shelled out: `git` may be absent, slow, or blocked by the
 * sandbox, and a status line must never be the reason a prompt stalls. A
 * detached head reports no branch rather than a bare revision, which would read
 * as a branch named after a hash.
 * @param cwd - directory to start from.
 * @returns the branch name, or undefined outside a repository or when detached.
 */
export declare function gitBranch(cwd: string): Promise<string | undefined>;
/**
 * Render the status line.
 *
 * Segments that have nothing to report are dropped rather than shown empty, so
 * a fresh session reads as short rather than as broken.
 * @param facts - what to report.
 * @param theme - styling for the segments.
 * @param columns - display columns available; a longer line is cut, never wrapped.
 * @returns the line, unstyled when the theme is plain.
 */
export declare function statusLine(facts: StatusFacts, theme: Theme, columns: number): string;
/**
 * Render the fuller readout `/status` answers with.
 *
 * The status line is a glance; this is the place a person looks when the glance
 * raised a question, so it names each usage bucket rather than one total.
 * @param facts - what to report.
 * @param session - the session identity, which `--resume` takes.
 * @returns the report, one `label: value` per line.
 */
export declare function statusReport(facts: StatusFacts, session: string): string;

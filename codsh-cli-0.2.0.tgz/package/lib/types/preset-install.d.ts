/**
 * Installing this bundle's own preset into the Harness home.
 *
 * The launcher owns the roster's `roots`: `composeProfile` overwrites that key
 * with the installed app's shipped directory, so a bundle cannot contribute a
 * search root of its own. What it can reach is the writable user root the
 * roster appends by default, which is why a packaged preset is copied there
 * rather than pointed at in place.
 *
 * The copy is idempotent and never overwrites: a preset a person edited — or
 * one a newer package version would change — stays as it is, because the user
 * root is theirs. Removing the directory restores the packaged copy.
 * @module codsh-cli/src/preset-install
 */
/** The preset this bundle's patch names as the roster default. */
export declare const PACKAGED_PRESET = "code-cli";
/** What one install attempt did. */
export interface PresetInstallResult {
    /** Absolute directory the preset occupies after the attempt. */
    path: string;
    /** Whether this call created it; false when it was already present. */
    installed: boolean;
}
/**
 * Where {@link installPackagedPreset} puts the preset by default.
 * @returns the absolute preset directory under the Harness home's user root.
 */
export declare function packagedPresetPath(): string;
/**
 * Copy the packaged preset into the user root unless it is already there.
 * @param home - the user preset root; defaults to the Harness home's.
 * @returns where the preset lives and whether this call wrote it.
 */
export declare function installPackagedPreset(home?: string): Promise<PresetInstallResult>;
